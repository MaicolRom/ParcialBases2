--Numero de personas de la sede_Norte
SELECT COUNT(*) as sede_Norte FROM PERSONA WHERE FK_ID_sede=1

--Numero de personas de la sede Centro
SELECT COUNT(*) as sede_Centro FROM PERSONA WHERE FK_ID_sede=2

--Numero de personas de la sede SUR
SELECT COUNT(*) as sede_Sur FROM PERSONA WHERE FK_ID_sede=3

--Numero de personas de la sede Occidente
SELECT COUNT(*) as sede_Occidente FROM PERSONA WHERE FK_ID_sede=4

--Numero de personas de la sede Oriente
SELECT COUNT(*) as sede_Oriente FROM PERSONA WHERE FK_ID_sede=5
