--Numero de personas de ESTRATO_1
SELECT COUNT(*) as ESTRATO_1 FROM PERSONA WHERE FK_ID_estrato=1

--Numero de personas de ESTRATO_2
SELECT COUNT(*) as ESTRATO_2 FROM PERSONA WHERE FK_ID_estrato=2

--Numero de personas de ESTRATO_3
SELECT COUNT(*) as ESTRATO_3 FROM PERSONA WHERE FK_ID_estrato=3

--Numero de personas de ESTRATO_4
SELECT COUNT(*) as ESTRATO_4 FROM PERSONA WHERE FK_ID_estrato=4

--Numero de personas de ESTRATO_5
SELECT COUNT(*) as ESTRATO_5 FROM PERSONA WHERE FK_ID_estrato=5