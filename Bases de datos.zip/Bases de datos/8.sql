SELECT * FROM PERSONAS WHERE fecha_de_contratacion
 >= '2000-01-01'
  and fecha_de_contratacion
 <= '2005-01-01'